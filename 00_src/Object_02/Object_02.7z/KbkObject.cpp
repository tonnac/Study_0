#include "KbkObject.h"

bool KbkObject::Frame()
{
	return true;
}