#include "Button.h"

bool Button::Frame()
{
	return true;
}