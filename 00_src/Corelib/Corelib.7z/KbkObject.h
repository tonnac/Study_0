#pragma once
#include "KObject.h"
class KbkObject : public KObject
{
public:
	bool			Frame() override;
};