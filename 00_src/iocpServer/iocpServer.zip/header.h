#pragma once
#include <WinSock2.h>
#include <iostream>
#include <WS2tcpip.h>

#pragma comment(lib, "ws2_32")