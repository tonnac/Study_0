#include "StudentHandler.h"

int main()
{
	srand(time(NULL));
	StudentHandler p1;
	p1.MainMenu();
	return 0;
}